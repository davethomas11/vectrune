Vectrune 0.3.2 developer starter

Install Vectrune 0.3.2 or newer from:
https://github.com/davethomas11/vectrune/releases
macOS/Homebrew: brew install davethomas11/vectrune/vectrune
For an existing installation: brew update && brew upgrade vectrune

Open a terminal in the extracted folder and run:
  vectrune --version
  vectrune doctor .
  vectrune fmt . --check
  vectrune check . --deny-warnings
  vectrune test .
Expected: 5 passed, 0 failed.

During development:
  vectrune test . --watch

Keep tests and test-only fixtures in .test.rune files. Application directory
imports and Lambda bundles exclude them. Application files cannot explicitly
import test modules; tests can import application modules and test helpers.

The fixture and suite hooks are in api.test.rune. Tests use the real native
router without opening a port. Each test starts with fresh Rune memory.
External files/databases are not rolled back. Main execution and cleanup each
have a bounded timeout. Ctrl-C stops watch mode; abrupt process termination
cannot guarantee teardown. The included GitHub workflow is pinned to 0.3.2.

Run the server separately if wanted:
  vectrune app.rune
  curl http://127.0.0.1:3000/health
